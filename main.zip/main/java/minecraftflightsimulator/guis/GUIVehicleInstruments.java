package minecraftflightsimulator.guis;

import minecraftflightsimulator.entities.core.EntityVehicle;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class GUIVehicleInstruments extends GuiScreen{
	private static final ResourceLocation background = new ResourceLocation("mfs", "textures/guis/long_blank.png");
	private final int xSize = 176;
	private final int ySize = 222;
	private final EntityVehicle vehicle;
	private final EntityPlayer player;
	
	private int guiLeft;
	private int guiTop;
	
	public GUIVehicleInstruments(EntityVehicle vehicle, EntityPlayer player){
		super();
		this.vehicle = vehicle;
		this.player = player;
	}
	
	@Override 
	public void initGui(){
		super.initGui();
		guiLeft = (this.width - this.xSize)/2;
		guiTop = (this.height - this.ySize)/2;
	}
	
	@Override
    public void drawScreen(int mouseX, int mouseY, float renderPartialTicks){
		
	}
	
	@Override
    protected void mouseClicked(int x, int y, int button){
		
	}
}
