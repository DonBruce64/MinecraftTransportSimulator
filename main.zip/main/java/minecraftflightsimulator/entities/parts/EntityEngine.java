package minecraftflightsimulator.entities.parts;

import minecraftflightsimulator.MFS;
import minecraftflightsimulator.MFSRegistry;
import minecraftflightsimulator.entities.core.EntityChild;
import minecraftflightsimulator.entities.core.EntityVehicle;
import minecraftflightsimulator.minecrafthelpers.BlockHelper;
import minecraftflightsimulator.minecrafthelpers.ItemStackHelper;
import minecraftflightsimulator.sounds.EngineSound;
import minecraftflightsimulator.systems.ConfigSystem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public abstract class EntityEngine extends EntityChild{
	protected EntityVehicle vehicle;
	
	//NBT data
	public EngineTypes type;
	public boolean oilLeak;
	public boolean fuelLeak;
	public boolean brokenStarter;
	public int model;
	public int maxRPM;
	public int maxSafeRPM;
	public float fuelConsumption;
	public double hours;
	
	//Runtime data
	public EngineStates state;
	public byte starterLevel;
	public int internalFuel;
	public double fuelFlow;
	public double RPM;
	public double temp = 20;
	public double oilPressure = 90;
	private EngineSound engineSound;
	
	//Constants
	public static final float engineStallRPM = 300;
	public static final float engineStartRPM = 500;
	public static final float engineColdTemp = 30F;
	public static final float engineHotTemp = 93.3333F;
	public static final float engineOverheatTemp1 = 107.222F;
	public static final float engineOverheatTemp2 = 121.111F;
	public static final float engineFireTemp = 130F;
	public static final float engineFailureTemp = 150F;
	public static final float engineOilDanger = 40F;
	public static final float engineOilCritical = 10F;

	public EntityEngine(World world){
		super(world);
	}

	public EntityEngine(World world, EntityVehicle vehicle, String parentUUID, float offsetX, float offsetY, float offsetZ, int propertyCode){
		super(world, vehicle, parentUUID, offsetX, offsetY, offsetZ, EngineTypes.values()[propertyCode].size, EngineTypes.values()[propertyCode].size, propertyCode);
		this.type = EngineTypes.values()[propertyCode];
		this.state = EngineStates.ENGINE_OFF;
	}
	
	@Override
	public void setNBTFromStack(ItemStack stack){
		NBTTagCompound stackNBT = ItemStackHelper.getStackNBT(stack);
		oilLeak=stackNBT.getBoolean("oilLeak");
		fuelLeak=stackNBT.getBoolean("fuelLeak");
		brokenStarter=stackNBT.getBoolean("brokenStarter");
		model = stackNBT.getInteger("model");
		hours = stackNBT.getDouble("hours");
		maxRPM = stackNBT.getInteger("maxRPM");
		maxSafeRPM = stackNBT.getInteger("maxSafeRPM");
		fuelConsumption = stackNBT.getFloat("fuelConsumption");
	}
	
	@Override
	public ItemStack getItemStack(){
		ItemStack engineStack = new ItemStack(MFSRegistry.engine, 1, type.ordinal());
		NBTTagCompound tag = new NBTTagCompound();
		tag.setBoolean("oilLeak", this.oilLeak);
		tag.setBoolean("fuelLeak", this.fuelLeak);
		tag.setBoolean("brokenStarter", this.brokenStarter);
		tag.setInteger("model", model);
		tag.setInteger("maxRPM", maxRPM);
		tag.setInteger("maxSafeRPM", maxSafeRPM);
		tag.setFloat("fuelConsumption", fuelConsumption);
		tag.setDouble("hours", hours);
		ItemStackHelper.setStackNBT(engineStack, tag);
		return engineStack;
	}
	
	@Override
	public boolean performAttackAction(DamageSource source, float damage){
		if(!worldObj.isRemote){
			if(isDamageWrench(source)){
				return true;
			}
			if(source.isExplosion()){
				hours += damage*10;
				oilLeak = Math.random() > ConfigSystem.getDoubleConfig("EngineLeakProbability")*10;
				fuelLeak = Math.random() > ConfigSystem.getDoubleConfig("EngineLeakProbability")*10;
				brokenStarter = Math.random() > 0.05;
			}else{
				hours += damage;
				if(source.isProjectile()){
					oilLeak = Math.random() > ConfigSystem.getDoubleConfig("EngineLeakProbability");
					fuelLeak = Math.random() > ConfigSystem.getDoubleConfig("EngineLeakProbability");
				}
			}
			this.sendDataToClient();
		}
		return true;
    }
	
	@Override
	public void onUpdate(){
		super.onUpdate();
		if(!linked){return;}
		vehicle = (EntityVehicle) this.parent;
		
		if(isBurning()){
			hours += 0.1;
			if(BlockHelper.isPositionInLiquid(worldObj, posX, posY + 0.25, posZ)){
				temp -= 0.3;
			}else{
				temp += 0.3;
			}
			if(temp > engineFailureTemp || fuelLeak){
				explodeEngine();
				return;
			}
		}
		
		//TODO remove this with gas pump
		vehicle.fuel = 100;
		//Equation is (engine temperature - ambient temperature(biome specific))*(rate of change)
		temp -= (temp - (25*worldObj.getBiomeGenForCoords((int) this.posX, (int) this.posZ).temperature*(1 - posY/800)))*(0.25 + vehicle.velocity/4F)/200F;
		vehicle.electricUsage -= 0.01*RPM/maxRPM;
		if(state.running){
			oilPressure = Math.min(90 - temp/10, oilPressure + 0.5F*(RPM/500 - (oilLeak ? 2F : 1F)*(oilPressure/80)));				
			if(oilPressure < 30){
				temp += RPM/2500F/2F;
				hours += 0.01;
			}else{
				temp += RPM/5000F/2F;
				hours += 0.001;	
			}
			if(RPM > engineStartRPM*1.5 && temp < engineColdTemp){//Not warmed up
				hours += 0.001*(RPM/engineStartRPM - 1);
			}
			if(RPM > getMaxSafeRPM(maxRPM)){//Too fast
				hours += 0.001*(RPM - getMaxSafeRPM(maxRPM))/10F;
				temp += (RPM - getMaxSafeRPM(maxRPM))/1000;
			}
			if(temp > engineHotTemp){//Too hot, 200 by gauge standard
				hours += 0.001*(temp - engineHotTemp);
				if(temp > engineFireTemp){
					setFire(10);
				}
			}
			
			if(hours > 200){
				if(Math.random() > hours/(200*1200)){
					RPM -= 100;
					//TODO get sputter sound.
					MFS.proxy.playSound(this, "mfs:engine_sputter", 1, 1);
				}
			}

			fuelFlow = Math.min(this.fuelConsumption*ConfigSystem.getDoubleConfig("FuelUsageFactor")*RPM*(fuelLeak ? 1.5F : 1.0F)/maxRPM, vehicle.fuel);
			vehicle.fuel -= fuelFlow;
			if(vehicle.fuel == 0){
				internalFuel = 100;
				stallEngine();
			}else if(RPM < engineStallRPM){
				internalFuel = 100;
				stallEngine();
			}else if(BlockHelper.isPositionInLiquid(worldObj, posX, posY, posZ)){
				MFS.proxy.playSound(this, "mfs:engine_starting", 1, 1);
				stallEngine();
			}
		}else{
			oilPressure = 0;
			if(RPM > engineStartRPM){
				if(vehicle.fuel > 0){
					if(!BlockHelper.isPositionInLiquid(worldObj, posX, posY + 0.25, posZ)){
						if(state.magnetoOn){
							startEngine();
						}
					}
				}
			}
			
			//Internal fuel is used for engine sound wind down.  NOT used for power.
			if(internalFuel > 0){
				--internalFuel;
				if(RPM < 1000){
					internalFuel = 0;
				}
			}
		}
		
		//Check to see if electric or hand starter can keep running.
		if(state.esOn){
			if(starterLevel == 0){
				if(vehicle.electricPower > 2){
					starterLevel += type.starterIncrement;
					if(vehicle.electricPower > 6){
						MFS.proxy.playSound(this, "mfs:" + type.engineCrankingSoundName, 1, 1);
					}else{
						MFS.proxy.playSound(this, "mfs:" + type.engineCrankingSoundName, 1, (float) (vehicle.electricPower/8F));
					}
				}
			}
			if(starterLevel > 0){
				vehicle.electricUsage += 0.01F;
				if(vehicle.fuel > this.fuelConsumption*ConfigSystem.getDoubleConfig("FuelUsageFactor")){
					vehicle.fuel -= this.fuelConsumption*ConfigSystem.getDoubleConfig("FuelUsageFactor");
					fuelFlow += this.fuelConsumption*ConfigSystem.getDoubleConfig("FuelUsageFactor");
				}
			}
		}else if(state.hsOn){
			if(starterLevel == 0){
				state = state.magnetoOn ? EngineStates.MAGNETO_ON_STARTERS_OFF : EngineStates.ENGINE_OFF;
			}
		}
		
		if(starterLevel > 0){
			--starterLevel;
			if(RPM < 600){
				RPM = Math.min(RPM+type.starterPower, 600);
			}else{
				RPM = Math.max(RPM-type.starterPower, 600);
			}
		}
		engineSound = MFS.proxy.updateEngineSoundAndSmoke(engineSound, this);
	}

	@Override
	public void setDead(){
		super.setDead();
		state = EngineStates.ENGINE_OFF;
		internalFuel = 0;
		engineSound = MFS.proxy.updateEngineSoundAndSmoke(engineSound, this);
	}
	
	public void setMagnetoStatus(boolean on){
		if(on){
			if(state.equals(EngineStates.MAGNETO_OFF_ES_ON)){
				state = EngineStates.MAGNETO_ON_ES_ON;
			}else if(state.equals(EngineStates.MAGNETO_OFF_HS_ON)){
				state = EngineStates.MAGNETO_ON_HS_ON;
			}else if(state.equals(EngineStates.ENGINE_OFF)){
				state = EngineStates.MAGNETO_ON_STARTERS_OFF;
			}
		}else{
			if(state.equals(EngineStates.MAGNETO_ON_ES_ON)){
				state = EngineStates.MAGNETO_OFF_ES_ON;
			}else if(state.equals(EngineStates.MAGNETO_ON_HS_ON)){
				state = EngineStates.MAGNETO_OFF_HS_ON;
			}else if(state.equals(EngineStates.MAGNETO_ON_STARTERS_OFF)){
				state = EngineStates.ENGINE_OFF;
			}else if(state.equals(EngineStates.RUNNING)){
				state = EngineStates.ENGINE_OFF;
				internalFuel = 100;
				MFS.proxy.playSound(this, "mfs:engine_starting", 1, 1);
			}
		}
	}
	
	public void setElectricStarterStatus(boolean engaged){
		if(!brokenStarter){
			if(engaged){
				if(state.equals(EngineStates.ENGINE_OFF)){
					state = EngineStates.MAGNETO_OFF_ES_ON;
				}else if(state.equals(EngineStates.MAGNETO_ON_STARTERS_OFF)){
					state = EngineStates.MAGNETO_ON_ES_ON;
				}else if(state.equals(EngineStates.RUNNING)){
					state =  EngineStates.RUNNING_ES_ON;
				}
			}else{
				if(state.equals(EngineStates.MAGNETO_OFF_ES_ON)){
					state = EngineStates.ENGINE_OFF;
				}else if(state.equals(EngineStates.MAGNETO_ON_ES_ON)){
					state = EngineStates.MAGNETO_ON_STARTERS_OFF;
				}else if(state.equals(EngineStates.RUNNING_ES_ON)){
					state = EngineStates.RUNNING;
				}
			}
		}
	}
	
	public void handStartEngine(){
		if(state.equals(EngineStates.ENGINE_OFF)){
			state = EngineStates.MAGNETO_OFF_HS_ON;
		}else if(state.equals(EngineStates.MAGNETO_ON_STARTERS_OFF)){
			state = EngineStates.MAGNETO_ON_HS_ON;
		}else if(state.equals(EngineStates.RUNNING)){
			state = EngineStates.RUNNING_HS_ON;
		}else{
			return;
		}
		starterLevel += type.starterIncrement;
		MFS.proxy.playSound(this, "mfs:" + type.engineCrankingSoundName, 1, 1);
	}
	
	private void startEngine(){
		MFS.proxy.playSound(this, "mfs:engine_starting", 1, 1);
		if(state.equals(EngineStates.MAGNETO_ON_STARTERS_OFF)){
			state = EngineStates.RUNNING;
		}else if(state.equals(EngineStates.MAGNETO_ON_ES_ON)){
			state = EngineStates.RUNNING_ES_ON;
		}else if(state.equals(EngineStates.MAGNETO_ON_HS_ON)){
			state = EngineStates.RUNNING_HS_ON;
		}
		starterLevel = 0;
		if(!worldObj.isRemote){
			this.sendDataToClient();
		}
	}
	
	private void stallEngine(){
		MFS.proxy.playSound(this, "mfs:engine_starting", 1, 1);
		if(state.equals(EngineStates.RUNNING)){
			state = EngineStates.MAGNETO_ON_STARTERS_OFF;
		}else if(state.equals(EngineStates.RUNNING_ES_ON)){
			state = EngineStates.MAGNETO_ON_ES_ON;
		}else if(state.equals(EngineStates.RUNNING_HS_ON)){
			state = EngineStates.MAGNETO_ON_HS_ON;
		}
		if(!worldObj.isRemote){
			this.sendDataToClient();
		}
	}
	
	protected void explodeEngine(){
		worldObj.newExplosion(this, posX, posY, posZ, 1F, true, true);
		this.parent.removeChild(this.UUID, false);
	}
	
	public EngineSound getEngineSound(){
		if(worldObj.isRemote){
			if(type != null){
				return new EngineSound(new ResourceLocation("mfs:" + type.engineRunningSoundName), this, 2000F);
			}
		}
		return null;
	}
	
	public static int getMaxSafeRPM(int maxRPM){
		return (maxRPM - (maxRPM - 2500)/2);
	}
	
	public enum EngineTypes{
		PLANE_SMALL((byte) 4, (byte) 50, 1.0F, "small_engine_running", "small_engine_cranking", (short) 2703, (short) 2905), 
		PLANE_LARGE((byte) 22, (byte) 25, 1.2F, "large_engine_running", "large_engine_cranking", (short) 2010, (short) 2412),
		HELICOPTER((byte) 100, (byte) 100, 1.2F, "helicopter_engine_running", "helicopter_engine_cranking", (short) 3500, (short) 3700),
		VEHICLE((byte) 100, (byte) 100, 1.2F, "vehicle_engine_running", "vehicle_engine_cranking", (short) 3500, (short) 3700);
		//TODO find other sounds
		
		public final byte starterIncrement;
		public final byte starterPower;
		public final float size;
		public final String engineRunningSoundName;
		public final String engineCrankingSoundName;
		public final short[] defaultSubtypes;
		private EngineTypes(byte starterIncrement, byte starterPower, float size, String engineRunningSoundName, String engineCrankingSoundName, short... defaultSubtypes){
			this.starterIncrement = starterIncrement;
			this.starterPower = starterPower;
			this.size = size;
			this.engineRunningSoundName = engineRunningSoundName;
			this.engineCrankingSoundName = engineCrankingSoundName;
			this.defaultSubtypes = defaultSubtypes;
		}
	}
	
	/**
	 * Engine states have 5 components.  Magneto, electric starter, hand starter, power status, and drowned out.
	 */
	public enum EngineStates{
		ENGINE_OFF(false, false, false, false),
		MAGNETO_ON_STARTERS_OFF(true, false, false, false),
		MAGNETO_OFF_ES_ON(false, true, false, false),
		MAGNETO_OFF_HS_ON(false, false, true, false),
		MAGNETO_ON_ES_ON(true, true, false, false),
		MAGNETO_ON_HS_ON(true, false, true, false),
		RUNNING(true, false, false, true),
		RUNNING_ES_ON(true, true, false, true),
		RUNNING_HS_ON(true, false, true, true);
		
		public final boolean magnetoOn;
		public final boolean esOn;
		public final boolean hsOn;
		public final boolean running;
		
		private EngineStates(boolean magnetoOn, boolean esOn, boolean hsOn, boolean running){
			this.magnetoOn = magnetoOn;
			this.esOn = esOn;
			this.hsOn = hsOn;
			this.running = running;
		}
	}
		
	@Override
	public void readFromNBT(NBTTagCompound tagCompound){
		super.readFromNBT(tagCompound);
		this.type=EngineTypes.values()[tagCompound.getByte("type")];
		this.state=EngineStates.values()[tagCompound.getByte("state")];
		this.oilLeak=tagCompound.getBoolean("oilLeak");
		this.fuelLeak=tagCompound.getBoolean("fuelLeak");
		this.brokenStarter=tagCompound.getBoolean("brokenStarter");
		this.model=tagCompound.getInteger("model");
		this.maxRPM=tagCompound.getInteger("maxRPM");
		this.maxSafeRPM=tagCompound.getInteger("maxSafeRPM");
		this.fuelConsumption=tagCompound.getFloat("fuelConsumption");
		this.hours=tagCompound.getDouble("hours");
		this.RPM=tagCompound.getDouble("RPM");
		this.temp=tagCompound.getDouble("temp");
		this.oilPressure=tagCompound.getDouble("oilPressure");
	}
	
	@Override
	public void writeToNBT(NBTTagCompound tagCompound){
		super.writeToNBT(tagCompound);
		tagCompound.setByte("type", (byte) this.type.ordinal());
		tagCompound.setByte("state", (byte) this.state.ordinal());
		tagCompound.setBoolean("oilLeak", this.oilLeak);
		tagCompound.setBoolean("fuelLeak", this.fuelLeak);
		tagCompound.setBoolean("brokenStarter", this.brokenStarter);
		tagCompound.setInteger("model", this.model);
		tagCompound.setInteger("maxRPM", this.maxRPM);
		tagCompound.setInteger("maxSafeRPM", this.maxSafeRPM);
		tagCompound.setFloat("fuelConsumption", this.fuelConsumption);
		tagCompound.setDouble("hours", this.hours);
		tagCompound.setDouble("RPM", this.RPM);
		tagCompound.setDouble("temp", this.temp);
		tagCompound.setDouble("oilPressure", this.oilPressure);
	}
}
